import { sfx, play, haptic, setHaptic } from './sfx'
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { ArrowDownLeft, ArrowUpRight, ChevronLeft, Gamepad2, Gift, ListChecks, Package, Plus, Trophy, UserRound, Volume2, VolumeX, X } from 'lucide-react'
import { Coin, GiftArt, TonIcon, UsdtIcon } from './art'
import { ACHIEVEMENTS, DAILY_XP, TASK_XP, betXp, levelInfo, rankOf } from './levels'
import { DEMO, SAVE_KEY } from './lib'
import { tgName } from './auth'
import { DepositModal, liveRates, ownerDemoUnlocked, useLocalDeposits } from './deposit'
import { track, flushSync } from './sync'
import { WithdrawModal, loadWithdrawCfg, useWithdrawRetry, type WCfg } from './withdraw'
import { GAME_INFO } from './menuart'
import {

  Blackjack, Cases, Coinflip, Crash, HiLo, Mansion, Mines, Plinko, Race, Slots, Storm, Upgrade, type Ctx,
} from './games'
import { Dice, Wheel, WheelMenu, Scratch, Tower } from './games2'
import { Keno, Roulette } from './games3'
import { BrandDefs, Logotype } from './brand'
import { FxConfetti, StreakChip, LevelUp, DailyStrip, Collection, LookCard } from './feel'
import { LiveFeed, ReferralCard } from './feed'
import {
  CASE, CASES, DISP, cfmt, CASE_CATS, pctText, GAME_TITLE, caseOddsOf, FLAGS, houseTilt, GIFTS, GIFT_ORDER, COINS_PER_TON, SELL_RATE, STARS_TO_COINS, dateNow, defaultSave, defsFromImport, defsFromNft, loadSave, savedElsewhere, markLoaded, mergeCatalog, mergeNft, money, persist, setCatalog, todayKey, uid, walkPrices,
  type ImportedGift, type NftCollection,
  type Gift as GiftT, type GiftKind, type Save, type Tx,
} from './lib'

type Tab = 'Игры' | 'Кейсы' | 'Подарки' | 'Задания' | 'Профиль'
type GameId = 'upgrade' | 'storm' | 'rocket' | 'slots' | 'cases' | 'mansion' | 'coin' | 'mines' | 'blackjack' | 'plinko' | 'racing' | 'hilo' | 'dice' | 'wheel' | 'scratch' | 'tower' | 'keno' | 'roulette'
type GameDef = { id: GameId; name: string; image: string; players: string; tag?: string; desc: string; soon?: boolean }

const tabs: { label: Tab; icon: typeof Gamepad2 }[] = [
  { label: 'Игры', icon: Gamepad2 }, { label: 'Кейсы', icon: Package }, { label: 'Подарки', icon: Gift },
  { label: 'Задания', icon: ListChecks }, { label: 'Профиль', icon: UserRound },
]
const games: GameDef[] = [
  { id: 'upgrade', name: 'Апгрейд', image: 'upgrade', players: '1 240', tag: 'HOT', desc: 'Несколько подарков в один редкий' },
  { id: 'storm', name: 'Шторм', image: 'storm', players: '3 410', tag: 'X500', desc: 'Слот 5×3, девять линий' },
  { id: 'rocket', name: 'Ракета', image: 'launch', players: '2 080', tag: 'LIVE', desc: 'Забери множитель до вылета' },
  { id: 'cases', name: 'Кейсы', image: 'cases', players: '117', tag: 'NEW', desc: 'Открой до 10 кейсов за раз' },
  { id: 'slots', name: 'Быстрые слоты', image: 'cases', players: '284', desc: 'Три барабана, один спин' },
  { id: 'mines', name: 'Мины', image: 'mines', players: '29', desc: 'Открывай клетки, избегай мин' },
  { id: 'plinko', name: 'Plinko', image: 'storm', players: '15', desc: 'Шар падает на множитель' },
  { id: 'blackjack', name: 'Блэкджек', image: 'cases', players: '10', desc: 'Набери 21 очко' },
  { id: 'mansion', name: 'Особняк', image: 'mansion', players: '27', tag: 'NEW', desc: 'Поднимайся по этажам, обходи призраков' },
  { id: 'coin', name: 'Орёл и решка', image: 'upgrade', players: '58', tag: 'NEW', desc: 'Серия побед и множитель ×1,9' },
  { id: 'hilo', name: 'Больше / Меньше', image: 'mines', players: '96', tag: 'NEW', desc: 'Угадай: число больше или меньше' },
  { id: 'dice', name: 'Кости', image: 'dice', players: '73', tag: 'NEW', desc: 'Один кубик или сумма двух, шанс на выбор' },
  { id: 'wheel', name: 'Колесо удачи', image: 'wheel', players: '131', tag: 'NEW', desc: 'Колёса с подарками и NFT' },
  { id: 'scratch', name: 'Скретч-карты', image: 'scratch', players: '64', tag: 'NEW', desc: 'Сотри слой и найди три одинаковых' },
  { id: 'tower', name: 'Башня', image: 'tower', players: '52', tag: 'NEW', desc: 'Поднимайся по этажам, обходи ловушки' },
  { id: 'keno', name: 'Кено', image: 'keno', players: '48', tag: 'NEW', desc: 'Выбери до 10 чисел из 40' },
  { id: 'roulette', name: 'Рулетка', image: 'roulette', players: '89', tag: 'NEW', desc: 'Числа, цвета и дюжины' },
  { id: 'racing', name: 'Гонки', image: 'racing', players: '42', tag: 'NEW', desc: 'Ставь на машину: победитель или топ-3' },
]
const TITLES: Record<string, string> = Object.fromEntries(games.map(g => [g.id, g.name]))

const DAILY = [1, 2, 3, 4, 5, 6, 7] // дни серии входов
const DAILY_STARS = [1, 1, 1, 1, 1, 1, 1] // звёзд за вход по дням серии (по звезде за день)
const TASKS: { id: string; title: string; hint: () => string; stat: string; target: number }[] = [
  { id: 'crash3', title: '3 раунда в Ракете', hint: () => 'Любая ставка', stat: 'crash', target: 3 },
  { id: 'rounds10', title: '10 раундов в играх', hint: () => 'Любые игры', stat: 'rounds', target: 10 },
  { id: 'case1', title: 'Открыть кейс', hint: () => `Стоит ${CASE.price}`, stat: 'cases', target: 1 },
  { id: 'upg1', title: 'Сделать апгрейд', hint: () => 'Успешный или нет', stat: 'upgrades', target: 1 },
  { id: 'trade1', title: 'Купить или продать подарок', hint: () => 'На маркете', stat: 'trades', target: 1 },
]

export default function App() {
  const [save, setSave] = useState<Save>(() => { const s = loadSave(); markLoaded(); setCatalog(s.catalog); return s })
  const S = useRef(save)
  const [tab, setTab] = useState<Tab>('Игры')
  const [game, setGame] = useState<GameId | null>(null)
  const [seed, setSeed] = useState<string | null>(null)
  const [notice, setNotice] = useState('')
  // серия побед подряд: ставка без выплаты следующей ставкой считается проигрышем
  const [streak, setStreak] = useState(0)
  const pendingBet = useRef(false)
  const [lvlUp, setLvlUp] = useState<number | null>(null)
  const [theme, setTheme] = useState<'green' | 'graphite'>(() => { try { return localStorage.getItem('qcup-theme') === 'graphite' ? 'graphite' : 'green' } catch { return 'green' } })
  const [hapticOn, setHapticOn] = useState(haptic.on)
  useEffect(() => {
    document.documentElement.classList.toggle('gr', theme === 'graphite')
    try { localStorage.setItem('qcup-theme', theme) } catch { /* хранилище недоступно */ }
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'graphite' ? '#1e1f20' : '#1a2420')
  }, [theme])
  // всплывающая сумма у баланса: +выигрыш / −ставка, плашка при этом коротко пульсирует
  const prevBal = useRef(save.balance)
  const [delta, setDelta] = useState<{ id: number; v: number } | null>(null)
  useEffect(() => {
    const d = save.balance - prevBal.current; prevBal.current = save.balance
    if (!d || Math.abs(d) < 1) return
    const id = Date.now(); setDelta({ id, v: d })
    const t = window.setTimeout(() => setDelta(x => (x && x.id === id ? null : x)), 1300)
    return () => clearTimeout(t)
  }, [save.balance])
  const [sound, setSound] = useState(() => localStorage.getItem('qcup-sound') === '1')
  const [confetti, setConfetti] = useState(0)
  const [depositOpen, setDepositOpen] = useState(false)
  const [wdOpen, setWdOpen] = useState(false)
  const [wdCfg, setWdCfg] = useState<WCfg | null>(null)
  const [caseCat, setCaseCat] = useState('Все')
  const [caseMode, setCaseMode] = useState<'cases' | 'wheels'>('cases')
  const [demoOk, setDemoOk] = useState(false) // демо-режим владельца (адрес игры + #demo)
  useEffect(() => { ownerDemoUnlocked().then(setDemoOk) }, [])
  // если сохранение изменили в другой вкладке (например, demo.html), подхватываем без перезагрузки
  useEffect(() => {
    const h = (e: StorageEvent) => { if (e.key === SAVE_KEY) { const s = loadSave(); markLoaded(); S.current = s; setSave(s) } }
    window.addEventListener('storage', h)
    return () => window.removeEventListener('storage', h)
  }, [])
  // Валюта отображения баланса: звёзды игры, TON или USDT (пересчёт по рыночному курсу; ставки в играх всегда в звёздах)
  const [cur, setCur] = useState<'STAR' | 'TON' | 'USDT'>(() => { try { const v = localStorage.getItem('qcup-cur'); return v === 'TON' || v === 'USDT' ? v : 'STAR' } catch { return 'STAR' } })
  const [curMenu, setCurMenu] = useState(false)
  const [rates, setRates] = useState<{ ton: number; usdt: number } | null>(null)
  useEffect(() => {
    const load = () => liveRates().then(r => setRates({ ton: r.ton, usdt: r.usdt }))
    load()
    const t = window.setInterval(load, 60_000) // курс обновляется постоянно
    return () => clearInterval(t)
  }, [])
  const pickCur = (c: 'STAR' | 'TON' | 'USDT') => { setCur(c); setCurMenu(false); try { localStorage.setItem('qcup-cur', c) } catch { /* хранилище недоступно */ } }
  useEffect(() => { // выбор валюты из экранов игр (например, ставка звёздами в апгрейде)
    const on = (e: Event) => { const c = (e as CustomEvent<string>).detail; if (c === 'STAR' || c === 'TON' || c === 'USDT') pickCur(c) }
    window.addEventListener('qcup-cur', on); return () => window.removeEventListener('qcup-cur', on)
  })
  DISP.cur = cur; DISP.ton = rates?.ton || 0; DISP.usdt = rates?.usdt || 0 // игры и тексты показывают суммы в выбранной валюте
  const fmtBal = (stars: number) => cur === 'TON' && rates ? `${(stars / rates.ton).toFixed(3)} TON` : cur === 'USDT' && rates ? `${(stars / rates.usdt).toFixed(2)} USDT` : money(stars)

  const commit = useCallback((f: (s: Save) => Save) => {
    if (savedElsewhere()) { const fresh = loadSave(); markLoaded(); setCatalog(fresh.catalog); S.current = fresh } // другая вкладка уже сохранила более свежее состояние: работаем поверх него
    const next = f(S.current)
    if (next.catalog !== S.current.catalog) setCatalog(next.catalog)
    S.current = next
    setSave(next)
    persist(next)
  }, [])

  // Подарки Telegram: сначала автовыгрузка с бэкенда (бот подключён), иначе public/gifts/catalog.json
  useEffect(() => {
    const raw = (import.meta as any).env?.VITE_API_URL as string | undefined
    const API = raw === 'same' ? '' : raw?.replace(/\/$/, '') // 'same' = тот же домен (dev-прокси на бэкенд)
    type Cat = { gifts?: ImportedGift[]; updated?: string; demo?: boolean }
    const apply = (j: Cat, base: string, live: boolean) => {
      if (!j.gifts?.length) return false
      if (j.demo) FLAGS.demo = true
      else if (live) FLAGS.demo = false
      const defs = defsFromImport(j.gifts.map(g => ({ ...g, thumb: g.thumb ? base + g.thumb : null, anim: g.anim ? base + g.anim : null })))
      const ids = Object.keys(defs)
      if (!ids.length) return false
      const sig = `ids:${ids.join(',')}:k${STARS_TO_COINS}:v5` // одинаковый набор подарков из любого источника не применяется дважды
      if (localStorage.getItem('qcup-catalog-sig') === sig && S.current.catalog[ids[0]]) return true
      localStorage.setItem('qcup-catalog-sig', sig)
      for (const d of Object.values(defs)) if (d.thumb) { const im = new Image(); im.src = d.thumb } // прогреваем иконки
      commit(s => mergeCatalog(s, defs))
      setNotice(FLAGS.demo ? `Загружены демо-подарки: ${ids.length}` : `Подарки Telegram загружены: ${ids.length}`)
      return true
    }
    let dead = false, timer = 0
    const run = async () => {
      let live = false
      if (API !== undefined) {
        try {
          const r = await fetch(`${API}/api/gifts/catalog`, { cache: 'no-cache' })
          if (r.ok && apply((await r.json()) as Cat, API, true)) live = true
        } catch { /* бэкенд недоступен — берём статичный каталог */ }
      }
      if (!live) {
        try {
          const r = await fetch('./gifts/catalog.json', { cache: 'no-cache' })
          if (r.ok) apply((await r.json()) as Cat, './gifts/', false)
        } catch { /* каталога нет — работаем со встроенным набором */ }
      }
      // бэкенд мог ещё не успеть выгрузить подарки: повторяем, пока не получим живой каталог
      if (!dead && API !== undefined) timer = window.setTimeout(run, live ? 10 * 60_000 : 8_000)
    }
    run()
    return () => { dead = true; clearTimeout(timer) }
  }, [commit])

  // Автоподгрузка NFT-подарков с флор-ценами: бэкенд (/api/nft/floors) или статичный public/gifts/nft.json
  useEffect(() => {
    let dead = false
    const raw = (import.meta as any).env?.VITE_API_URL as string | undefined
    const API = raw === 'same' ? '' : raw?.replace(/\/$/, '')
    const load = async () => {
      // бэкенд -> открытый датасет флор-цен Fragment (напрямую, без ключей) -> демо public/gifts/nft.json
      const NAMES = 'https://raw.githubusercontent.com/gift-club/telegram-gifts-dataset/main/data/gift-collections.json'
      const OPEN = 'https://raw.githubusercontent.com/Atlannn/telegram-gifts-floor-price/main/data/latest.json'
      const sources = ['./gifts/nft.json', API !== undefined ? `${API}/api/nft/floors` : '', OPEN].filter(Boolean) // сначала локальный файл с ценами (мгновенно), потом свежие данные из сети
      for (const url of sources) {
        try {
          const r = await fetch(url, { cache: 'no-cache' })
          if (!r.ok) continue
          let j = (await r.json()) as { collections?: NftCollection[]; demo?: boolean; floors?: Record<string, number> }
          if (j.floors) {
            const names: Record<string, string> = {}
            try { for (const c of (await (await fetch(NAMES)).json()) as { slug: string; name: string }[]) names[c.slug] = c.name } catch { /* без красивых названий */ }
            j = { collections: Object.entries(j.floors).filter(([, v]) => v > 0).map(([id, floorTon]) => ({ id, name: names[id] || id.charAt(0).toUpperCase() + id.slice(1), floorTon, image: `https://fragment.com/file/gifts/${id}/thumb.webp` })) }
          }
          if (j.demo) FLAGS.demo = true
          const cols = (j.collections || []).map(c => (j.demo ? { ...c, floorTon: c.floorTon * (1 + (Math.random() - 0.5) * 0.08) } : c))
          // иконки и названия берём с этого компьютера (их сохраняет лаунчер), чтобы не зависеть от бэкенда и сети
          const [idx, nm] = await Promise.all([
            fetch('./gifts/nft/index.json').then(r => (r.ok ? r.json() : [])).catch(() => []) as Promise<string[]>,
            fetch('./gifts/nft/names.json').then(r => (r.ok ? r.json() : {})).catch(() => ({})) as Promise<Record<string, string>>,
          ])
          const have = new Set(idx)
          for (const c of cols) {
            if (j.demo) break
            if (nm[c.id]) c.name = nm[c.id]
            if (have.has(c.id)) c.image = `./gifts/nft/${c.id}.webp`
            else if (!c.image) c.image = `https://fragment.com/file/gifts/${c.id}/thumb.webp`
          }
          const defs = defsFromNft(cols)
          if (dead || !Object.keys(defs).length) continue
          commit(s => mergeNft(s, defs))
          if (url !== './gifts/nft.json') return
        } catch { /* пробуем следующий источник */ }
      }
    }
    load()
    const t = window.setInterval(load, FLAGS.demo ? 30_000 : 5 * 60_000)
    return () => { dead = true; clearInterval(t) }
  }, [commit])

  const user = (window as any).Telegram?.WebApp?.initDataUnsafe?.user
  const displayName: string = tgName(user)

  // Пополнения без бэкенда (GitHub Pages): сайт сам находит платёж в блокчейне и добавляет монеты
  useLocalDeposits(useCallback((coins: number, asset: string) => {
    commit(s => ({ ...s, balance: s.balance + coins, tx: [{ id: uid(), title: `Пополнение ${asset}`, amount: coins, date: dateNow() }, ...s.tx].slice(0, 60) }))
    setNotice(`Пополнение: +${cfmt(coins)}`)
  }, [commit]))

  // Пополнения: зачисленные на сервере монеты один раз попадают в баланс игр
  useEffect(() => {
    const raw = (import.meta as any).env?.VITE_API_URL as string | undefined
    const API = raw === 'same' ? '' : raw?.replace(/\/$/, '')
    const initData = (window as any).Telegram?.WebApp?.initData
    if (API === undefined || !initData) return
    const h = { 'content-type': 'application/json', 'x-telegram-init-data': initData }
    let busy = false
    const tick = async () => {
      if (busy) return
      busy = true
      try {
        const r = await fetch(`${API}/api/deposit/unclaimed`, { headers: h })
        if (!r.ok) return
        const rows = (await r.json()) as { id: string }[]
        if (!rows.length) return
        const c = await fetch(`${API}/api/deposit/claim`, { method: 'POST', headers: h, body: JSON.stringify({ ids: rows.map(x => x.id) }) })
        if (!c.ok) return
        const coins = Number((await c.json()).coins)
        if (coins > 0) {
          commit(s => ({ ...s, balance: s.balance + coins, tx: [{ id: uid(), title: 'Пополнение', amount: coins, date: dateNow() }, ...s.tx].slice(0, 60) }))
          setNotice(`Пополнение: +${cfmt(coins)}`)
        }
      } catch { /* повторим на следующем тике */ } finally { busy = false }
    }
    tick()
    const t = window.setInterval(tick, 6000)
    return () => clearInterval(t)
  }, [commit])

  useEffect(() => { localStorage.setItem('qcup-sound', sound ? '1' : '0'); sfx.enabled = sound }, [sound])
  useEffect(() => {
    if (!notice) return
    const t = window.setTimeout(() => setNotice(''), 3200)
    return () => clearTimeout(t)
  }, [notice])
  // Цены на маркете плавно меняются раз в 20 секунд
  useEffect(() => {
    const t = window.setInterval(() => commit(s => ({ ...s, prices: walkPrices(s.prices) })), 20000)
    return () => clearInterval(t)
  }, [commit])

  const beep = useCallback((f: number, _ms?: number) => { if (f < 300) play.lose(); else if (f > 800) play.coin(); else play.click() }, [])

  const lastStake = useRef(0)
  const ctx: Ctx = useMemo(() => {
    const tx = (title: string, amount: number): Tx => ({ id: uid(), title, amount, date: dateNow() })
    return {
      save,
      notify: setNotice,
      charge: (cost, title, countRound = true) => {
        if (!(cost > 0) || !Number.isFinite(cost)) return false
        lastStake.current = cost
        if (pendingBet.current) setStreak(0) // предыдущая ставка осталась без выигрыша
        pendingBet.current = true
        if (S.current.balance < cost) { setNotice('Не хватает звёзд'); beep(150, 200); return false }
        commit(s => ({
          ...s, balance: s.balance - cost, xp: (s.xp || 0) + (countRound ? betXp(cost) : 0),
          tx: [tx(title, -cost), ...s.tx].slice(0, 60),
          stats: { ...s.stats, rounds: (s.stats.rounds || 0) + (countRound ? 1 : 0), gStaked: (s.stats.gStaked || 0) + (GAME_TITLE.test(title) ? cost : 0) },
        }))
        if (GAME_TITLE.test(title)) track('bet', title.replace(/\s*[—:-].*$/, ''), cost)
        beep(380, 80)
        return true
      },
      pay: (amount, title) => {
        if (!(amount > 0)) return
        commit(s => ({ ...s, balance: s.balance + amount, tx: [tx(title, amount), ...s.tx].slice(0, 60), stats: { ...s.stats, gPaid: (s.stats.gPaid || 0) + (GAME_TITLE.test(title) ? amount : 0) } }))
        if (GAME_TITLE.test(title)) track('win', title.replace(/\s*[—:-].*$/, ''), amount)
        else track('sale', 'Продажа подарков', amount)
        if (GAME_TITLE.test(title)) { if (amount >= lastStake.current) setStreak(n => n + 1); else setStreak(0); pendingBet.current = false }
        setConfetti(c => c + 1); setNotice(`${title}: +${cfmt(amount)}`); beep(880, 220)
        if (GAME_TITLE.test(title)) { const st = lastStake.current; window.dispatchEvent(new CustomEvent('qcup-win', { detail: { amount, mult: st > 0 ? amount / st : 2, game: title.replace(/\s*[—:-].*$/, '') } })) }
      },
      addGift: (kind, title) => {
        const gift: GiftT = { uid: uid(), kind, num: S.current.nextNum }
        setStreak(n => n + 1); pendingBet.current = false
        commit(s => ({ ...s, seen: { ...(s.seen || {}), [kind]: true }, gifts: [...s.gifts, gift], nextNum: s.nextNum + 1 + Math.floor(Math.random() * 40), tx: [tx(`${title}: ${GIFTS[kind]?.name}`, 0), ...s.tx].slice(0, 60) }))
        setConfetti(c => c + 1); beep(988, 260)
        window.dispatchEvent(new CustomEvent('qcup-gift', { detail: { kind, game: title.replace(/\s*[—:-].*$/, '') } }))
        return gift
      },
      removeGift: id => commit(s => ({ ...s, gifts: s.gifts.filter(g => g.uid !== id) })),
      tally: (staked, paid) => { if (staked > 0) track('bet', 'Игры', staked); if (paid > 0) track('win', 'Игры', paid); commit(s => ({ ...s, stats: { ...s.stats, gStaked: (s.stats.gStaked || 0) + staked, gPaid: (s.stats.gPaid || 0) + paid } })) },
      tilt: () => 0, // подкрутки под игрока больше нет: везде честные шансы, преимущество казино заложено в таблицы выплат
      bump: key => commit(s => ({ ...s, stats: { ...s.stats, [key]: (s.stats[key] || 0) + 1 } })),
    }
  }, [save, commit, beep])

  const openGame = (id: GameId, seedUid: string | null = null) => { setSeed(seedUid); setGame(id) }
  const dailyReady = save.daily.last !== todayKey()
  const yday = new Date(Date.now() - 864e5).toISOString().slice(0, 10)
  const chain = save.daily.last === todayKey() || save.daily.last === yday ? save.daily.streak : 0 // сколько дней подряд уже отмечено
  const dailyDone = dailyReady ? chain % 7 : chain
  const dailyNext = dailyReady ? (chain % 7) + 1 : chain
  // коллекция: подарки, которые уже были у игрока (в том числе проданные и сгоревшие)
  const seenSet = useMemo(() => new Set([...Object.keys(save.seen || {}), ...save.gifts.map(g => g.kind)]), [save.seen, save.gifts])
  useEffect(() => {
    const miss = save.gifts.filter(g => !(save.seen || {})[g.kind])
    if (miss.length) commit(s => ({ ...s, seen: { ...(s.seen || {}), ...Object.fromEntries(s.gifts.map(g => [g.kind, true])) } }))
  }, [save.gifts, save.seen, commit])

  // ---- маркет ----
  const buy = (k: GiftKind) => {
    const price = S.current.prices[k]
    if (S.current.balance < price) return setNotice('Не хватает звёзд')
    ctx.charge(price, `Покупка: ${GIFTS[k]?.name}`, false)
    ctx.bump('trades')
    const g = ctx.addGift(k, 'Покупка')
    setNotice(`Куплено: ${GIFTS[k]?.name}`)
  }
  const sell = (g: GiftT) => {
    const price = Math.floor(S.current.prices[g.kind] * SELL_RATE)
    ctx.removeGift(g.uid)
    ctx.bump('trades')
    ctx.pay(price, `Продажа: ${GIFTS[g.kind]?.name}`)
  }
  // ---- задания ----
  const claimDaily = () => {
    if (!dailyReady) return
    const yesterday = new Date(Date.now() - 864e5).toISOString().slice(0, 10)
    const streak = save.daily.last === yesterday ? (save.daily.streak % 7) + 1 : 1
    const bonus = DAILY_STARS[streak - 1] || 1
    track('bonus', 'Ежедневный вход', bonus)
    commit(s => ({ ...s, daily: { last: todayKey(), streak }, balance: s.balance + bonus, xp: (s.xp || 0) + DAILY_XP, tx: [{ id: uid(), title: `Ежедневный вход · день ${streak}`, amount: bonus, date: dateNow() }, ...s.tx].slice(0, 60) }))
    if (streak === 7) { // награда за неделю подряд: редкий (коллекционный) подарок средней цены
      const pool = GIFT_ORDER.filter(k => GIFTS[k]?.nft && GIFTS[k].base >= 500 && GIFTS[k].base <= 3000)
      const kind = pool.length ? pool[Math.floor(Math.random() * pool.length)] : GIFT_ORDER.find(k => GIFTS[k]?.nft) || GIFT_ORDER[GIFT_ORDER.length - 1]
      if (kind) { ctx.addGift(kind, 'Награда за 7 дней'); setNotice(`7 дней подряд: ${GIFTS[kind]?.name} и +${cfmt(bonus)}`); return }
    }
    play.coin(); window.dispatchEvent(new CustomEvent('qcup-fx', { detail: 40 }))
    setNotice(`Ежедневный вход: день ${streak} из 7 · +${cfmt(bonus)}`)
  }
  const claimTask = (t: (typeof TASKS)[number]) => {
    if (save.tasks[t.id] || (save.stats[t.stat] || 0) < t.target) return
    commit(s => ({ ...s, tasks: { ...s.tasks, [t.id]: true }, xp: (s.xp || 0) + TASK_XP }))
    setNotice(`Задание выполнено: ${t.title} · +${TASK_XP} XP`)
  }
  // достижения выдаются автоматически, как только условие выполнено
  useEffect(() => {
    const fresh = ACHIEVEMENTS.filter(a => !(save.ach || {})[a.id] && a.test(save.stats))
    if (!fresh.length) return
    commit(s => ({ ...s, ach: { ...(s.ach || {}), ...Object.fromEntries(fresh.map(a => [a.id, true])) }, xp: (s.xp || 0) + fresh.reduce((n, a) => n + a.xp, 0) }))
    setNotice(`Достижение: ${fresh[0].title} · +${fresh[0].xp} XP${fresh.length > 1 ? ` (и ещё ${fresh.length - 1})` : ''}`)
  }, [save.stats, save.ach, commit])
  const lvl = levelInfo(save.xp || 0)

  // Вывод (тестовый): монеты списываются при заявке и возвращаются, если заявку отклонили
  const reserveWd = useCallback((coins: number) => {
    if (!(coins > 0) || S.current.balance < coins) return false
    commit(s => ({ ...s, balance: s.balance - coins, tx: [{ id: uid(), title: 'Вывод: заявка', amount: -coins, date: dateNow() }, ...s.tx].slice(0, 60) }))
    return true
  }, [commit])
  const refundWd = useCallback((coins: number, title: string) => {
    commit(s => ({ ...s, balance: s.balance + coins, tx: [{ id: uid(), title, amount: coins, date: dateNow() }, ...s.tx].slice(0, 60) }))
    setNotice(`${title}: +${cfmt(coins)}`)
  }, [commit])
  useWithdrawRetry(refundWd)
  useEffect(() => { loadWithdrawCfg().then(setWdCfg) }, [])
  // история игр уходит на сервер пачками: раз в 20 секунд и когда игрок сворачивает игру
  useEffect(() => {
    const f = () => flushSync({ balance: S.current.balance, level: levelInfo(S.current.xp || 0).level })
    const t = window.setInterval(f, 20_000)
    const v = () => { if (document.visibilityState === 'hidden') f() }
    document.addEventListener('visibilitychange', v); f()
    return () => { clearInterval(t); document.removeEventListener('visibilitychange', v) }
  }, [])
  const lvlRef = useRef(lvl.level)
  useEffect(() => {
    if (lvl.level > lvlRef.current) { setLvlUp(lvl.level); play.big(); window.dispatchEvent(new CustomEvent('qcup-fx', { detail: 120 })) }
    lvlRef.current = lvl.level
  }, [lvl.level])
  const view = (g: GameId) => {
    switch (g) {
      case 'rocket': return <Crash ctx={ctx} />
      case 'upgrade': return <Upgrade ctx={ctx} seed={seed} />
      case 'storm': return <Storm ctx={ctx} />
      case 'slots': return <Slots ctx={ctx} />
      case 'cases': return <Cases ctx={ctx} caseId={seed} />
      case 'mines': return <Mines ctx={ctx} />
      case 'plinko': return <Plinko ctx={ctx} />
      case 'blackjack': return <Blackjack ctx={ctx} />
      case 'mansion': return <Mansion ctx={ctx} />
      case 'coin': return <Coinflip ctx={ctx} />
      case 'racing': return <Race ctx={ctx} />
      case 'hilo': return <HiLo ctx={ctx} />
      case 'dice': return <Dice ctx={ctx} />
      case 'wheel': return <Wheel ctx={ctx} seed={seed} />
      case 'scratch': return <Scratch ctx={ctx} />
      case 'tower': return <Tower ctx={ctx} />
      case 'keno': return <Keno ctx={ctx} />
      case 'roulette': return <Roulette ctx={ctx} />
      default: return <p className="m center">Режим появится позже.</p>
    }
  }


  const header = (
    <header className="topbar">
      {game
        ? <button className="back-btn" onClick={() => setGame(null)} aria-label="Назад"><ChevronLeft size={20} /><span className="back-text"><span className="brand-word"><Logotype v="flat" h={18} /></span><small>{TITLES[game]}</small></span></button>
        : <button className="brand" onClick={() => setTab('Игры')}><span className="brand-word"><Logotype v="flat" h={20} /></span></button>}
      <div className="top-actions">
        {DEMO && <span className="demo-badge">ДЕМО</span>}
        {!game && <button className="dep-btn" onClick={() => setDepositOpen(true)}><Plus size={15} />Пополнить</button>}
        <button className="settings-btn" aria-label="Звук" onClick={() => setSound(s => !s)}>{sound ? <Volume2 size={16} /> : <VolumeX size={16} />}</button>
        <div className="cur-wrap">
          <button key={delta?.id ?? 0} className={`balance-pill${delta ? (delta.v > 0 ? ' bump-up' : ' bump-down') : ''}`} onClick={() => setCurMenu(o => !o)} aria-haspopup="menu" aria-expanded={curMenu}>{cur === 'TON' && rates ? <TonIcon size={18} /> : cur === 'USDT' && rates ? <UsdtIcon size={18} /> : <Coin />}<b>{fmtBal(save.balance)}</b><span className="cur-caret">▾</span>{delta && <span key={delta.id} className={`bal-delta ${delta.v > 0 ? 'up' : 'down'}`}>{delta.v > 0 ? '+' : '−'}{cfmt(Math.abs(delta.v))}</span>}</button>
          {curMenu && <><div className="cur-back" onClick={() => setCurMenu(false)} /><div className="cur-menu" role="menu">
            {([['STAR', 'Звёзды', <Coin size={18} />], ['TON', 'TON', <TonIcon size={18} />], ['USDT', 'USDT', <UsdtIcon size={18} />]] as ['STAR' | 'TON' | 'USDT', string, ReactNode][]).map(([k, t, ic]) =>
              <button key={k} role="menuitem" className={`cur-item ${cur === k ? 'on' : ''}`} onClick={() => pickCur(k)}>{ic}<span>{t}</span>{cur === k && <em>✓</em>}</button>)}
            <button role="menuitem" className="cur-prof" onClick={() => { setCurMenu(false); setGame(null); setTab('Профиль') }}>Профиль</button>
          </div></>}
        </div>
        <button className="avatar" onClick={() => { setGame(null); setTab('Профиль') }} aria-label={`Профиль, уровень ${lvl.level}`}>
          {user?.photo_url ? <img src={user.photo_url} alt="" /> : displayName.slice(0, 1).toUpperCase()}<span className="lvl-chip">{lvl.level}</span>
        </button>
      </div>
    </header>
  )

  return <main className="app-shell">
    <div className="bg-glow" />
    {header}

    {game ? <section className="game-view" data-game={game}>
      <div className="game-banner"><div className="gb-art"><img src={`./games/${games.find(x => x.id === game)?.image}.webp`} alt="" /></div>
        <div className="gb-text"><b>{TITLES[game]}</b><span>{GAME_INFO[game]?.sub}</span>
          <div className="gb-chips">{GAME_INFO[game]?.chips.map(c => <i key={c}>{c}</i>)}</div></div></div>
      {view(game)}
    </section> : <>
      {tab === 'Игры' && <>
        <DailyStrip stars={DAILY_STARS} done={dailyDone} ready={dailyReady} nextDay={dailyNext} onClaim={claimDaily} onOpen={() => setTab('Задания')} />
        <LiveFeed myName={displayName} />
        <section className="game-grid">
          {games.map(g => (
            <button className={`game-card${g.soon ? ' coming' : ''}`} key={g.id} onClick={() => g.soon ? setNotice('Этот режим скоро появится') : g.id === 'cases' ? setTab('Кейсы') : openGame(g.id)}>
              <div className="card-art-wrap"><img src={`./games/${g.image}.webp`} alt="" /><div className="card-glare" /></div>
              {!g.soon && <span className="players"><i /> {g.players} играют</span>}
              {g.tag && <span className={`game-tag ${g.tag}`}>{g.tag}</span>}
              <div className="card-glass"><b>{g.name}</b><p className="card-desc">{g.desc}</p></div>
            </button>
          ))}
        </section>
      </>}

      {tab === 'Кейсы' && <section className="page-section">
        <h1>{caseMode === 'cases' ? 'Кейсы' : 'Колёса удачи'}</h1>
        <div className="seg-switch" role="tablist">
          <button role="tab" aria-selected={caseMode === 'cases'} className={caseMode === 'cases' ? 'on' : ''} onClick={() => setCaseMode('cases')}>Кейсы</button>
          <button role="tab" aria-selected={caseMode === 'wheels'} className={caseMode === 'wheels' ? 'on' : ''} onClick={() => setCaseMode('wheels')}>Колёса удачи</button>
        </div>
        {caseMode === 'wheels' && <><p className="muted">Крути колесо с подарками или NFT. В секторах видно, что можно выиграть, и у каждого сектора равный шанс.</p><WheelMenu plain onPick={id => openGame('wheel', id)} /></>}
        {caseMode === 'cases' && <p className="muted">Из кейса выпадает подарок. Его можно оставить, продать или улучшить. В каждом кейсе есть шанс на главный приз.</p>}
        {caseMode === 'cases' && <div className="case-cats" role="tablist">
          {['Все', ...CASE_CATS.filter(cat => CASES.some(c => c.cat === cat))].map(cat => <button key={cat} role="tab" aria-selected={caseCat === cat} className={caseCat === cat ? 'on' : ''} onClick={() => setCaseCat(cat)}>{cat}<small>{cat === 'Все' ? CASES.length : CASES.filter(c => c.cat === cat).length}</small></button>)}
        </div>}
        {caseMode === 'cases' && CASE_CATS.filter(cat => (caseCat === 'Все' || caseCat === cat) && CASES.some(c => c.cat === cat)).map(cat => <div key={cat} className="case-group">
          {caseCat === 'Все' && <h3 className="case-cat">{cat}</h3>}
          <div className="case-list">
            {CASES.filter(c => c.cat === cat).sort((x, y) => x.price - y.price).map(c => (
              <button key={c.id} className="case-card" style={{ ['--cc' as string]: c.color }} onClick={() => openGame('cases', c.id)}>
                {c.tag && <em className="case-tag">{c.tag}</em>}
                <CaseIcon pool={c.pool} />
                <b>{c.name}</b>
                <span className="case-prize"><Trophy size={11} />{GIFTS[c.jp]?.name} · {pctText(c.jpChance)}</span>
                <span className="case-price">{cfmt(c.price)}</span>
              </button>
            ))}
          </div>
        </div>)}
      </section>}

      {tab === 'Подарки' && <GiftsTab save={save} ctx={ctx} onBuy={buy} onSell={sell} onUpgrade={uid => openGame('upgrade', uid)} />}

      {tab === 'Задания' && <section className="page-section">
        <h1>Задания</h1>
        <div className="daily-card">
          <div className="daily-top"><b>Ежедневный вход</b><span className="m small">Серия: {save.daily.streak} из 7</span></div>
          <div className="daily-days">{DAILY.map((r, i) => <span key={i} className={i < save.daily.streak ? 'done' : ''}><small>{i + 1}</small>{r}</span>)}</div>
          <button className="primary-btn wide" disabled={!dailyReady} onClick={claimDaily}>{dailyReady ? 'Отметить вход' : 'Отмечено, приходи завтра'}</button>
        </div>
        <div className="week-note m small">Лучшие по рейтингу недели получают настоящие подарки Telegram. Звёзды и подарки внутри игры вывести нельзя.</div>
        {TASKS.map(t => {
          const p = Math.min(t.target, save.stats[t.stat] || 0), done = !!save.tasks[t.id], ready = p >= t.target && !done
          return <div className="task-card" key={t.id}>
            <div><b>{t.title}</b><small>{t.hint()} · +{TASK_XP} XP</small>
              <div className="bar"><i style={{ width: `${(p / t.target) * 100}%` }} /></div></div>
            <strong>{p}/{t.target}</strong>
            <button disabled={!ready} onClick={() => claimTask(t)}>{done ? 'Готово' : ready ? 'Отметить' : 'В процессе'}</button>
          </div>
        })}
      </section>}

      {tab === 'Профиль' && <section className="page-section">
        <div className="profile-head"><div className="ava-col"><div className="profile-avatar">{user?.photo_url ? <img src={user.photo_url} alt="" /> : displayName.slice(0, 1).toUpperCase()}</div>
            <div className="ava-xp" title={`Уровень ${lvl.level}`}><i style={{ width: `${Math.round(lvl.pct * 100)}%` }} /></div><small>Ур. {lvl.level}</small></div>
          <div><h1>{displayName}</h1><p className="muted">{user?.username ? '@' + user.username : 'Гость'}</p></div></div>
        <div className="lvl-card">
          <div className="lvl-top"><div className="lvl-badge">{lvl.level}</div>
            <div><b>Уровень {lvl.level} · {rankOf(lvl.level)}</b><small>{lvl.need ? `${lvl.into} / ${lvl.need} XP до уровня ${lvl.level + 1}` : 'Максимальный уровень'}</small></div></div>
          <div className="lvl-bar"><i style={{ width: `${Math.round(lvl.pct * 100)}%` }} /></div>
          <p className="m small">Опыт: ставки (+2 за раунд и ещё за каждые 25 ⭐), задания +{TASK_XP}, ежедневный вход +{DAILY_XP}, достижения. Наград за уровни пока нет.</p>
        </div>
        <Collection kinds={GIFT_ORDER} seen={seenSet} names={k => GIFTS[k]?.name || k} />
        <LookCard theme={theme} onTheme={setTheme} haptic={hapticOn} onHaptic={v => { setHaptic(v); setHapticOn(v) }} />
        {wdCfg && <button className="wd-btn" onClick={() => setWdOpen(true)}><span><b>Вывод средств</b><small>Тестовый режим: заявку проверяет администратор</small></span><i>Вывести</i></button>}
        <ReferralCard onNotice={setNotice} />
        <div className="stats-row">
          <div><b>{fmtBal(save.balance)}</b><small>{cur === 'STAR' ? 'Звёзды' : 'Баланс'}</small></div>
          <div><b>{save.gifts.length}</b><small>Подарков</small></div>
          <div><b>{save.stats.rounds || 0}</b><small>Раундов</small></div>
        </div>
        <h2 className="section-title">Достижения · {Object.keys(save.ach || {}).length}/{ACHIEVEMENTS.length}</h2>
        <div className="ach-grid">
          {ACHIEVEMENTS.map(a => { const got = !!(save.ach || {})[a.id]; return (
            <div key={a.id} className={`ach ${got ? 'got' : ''}`}><span className="ach-ic">{a.icon}</span>
              <b>{a.title}</b><small>{a.desc}</small><em>{got ? 'Получено' : `+${a.xp} XP`}</em></div>) })}
        </div>
        <h2 className="section-title">Операции</h2>
        <TransactionList items={save.tx.slice(0, 20)} />
        <p className="fine-print">{DEMO ? 'Демо-версия для тестов: звёзды и подарки виртуальные, платежей нет, прогресс хранится отдельно от основной игры. «+10 000» вверху добавляет звёзды.' : 'Звёзды игры внутриигровые (1 звезда игры = 1 звезда по рыночному курсу) и не являются Telegram Stars. Баланс пополняется в TON или USDT, подарки существуют только внутри игры. Прогресс хранится в этом браузере.'}</p>
        {demoOk && <div className="demo-card">
          <b>Демо-режим (только для владельца)</b>
          <span>Тестовые звёзды, не связаны с платежами</span>
          <div className="demo-row">
            {[1000, 10000, 100000].map(n => <button key={n} onClick={() => { commit(s => ({ ...s, balance: s.balance + n, tx: [{ id: uid(), title: 'Демо-пополнение', amount: n, date: dateNow() }, ...s.tx].slice(0, 60) })); setNotice(`Демо: +${money(n)} ⭐`) }}>+{money(n)}</button>)}
            <button className="danger" onClick={() => { commit(s => ({ ...s, balance: 0 })); setNotice('Баланс обнулён') }}>Обнулить</button>
          </div>
        </div>}
      </section>}

      <nav className="bottom-nav">{tabs.map(({ label, icon: Icon }) =>
        <button key={label} className={tab === label ? 'nav-item active' : 'nav-item'} onClick={() => setTab(label)}>
          <Icon size={17} /><span>{label}</span>{label === 'Задания' && dailyReady && <em className="dot" />}
        </button>)}</nav>
    </>}

    {depositOpen && <DepositModal onClose={() => setDepositOpen(false)} onNotice={setNotice} />}
    {wdOpen && wdCfg && <WithdrawModal cfg={wdCfg} balance={save.balance} onClose={() => setWdOpen(false)} onReserve={reserveWd} onRefund={refundWd} onNotice={setNotice} />}
    <BrandDefs />
    <FxConfetti />
    <StreakChip n={streak} />
    {lvlUp !== null && <LevelUp level={lvlUp} rank={rankOf(lvlUp)} onClose={() => setLvlUp(null)} />}
    {notice && <button className="toast" onClick={() => setNotice('')}>{notice}<X size={15} /></button>}
    <Confetti count={confetti} key={confetti} />
  </main>
}

function CaseIcon({ pool }: { color?: string; id?: string; pool: string[] }) {
  const pick = [pool[Math.floor((pool.length - 1) / 2)], pool[pool.length - 1], pool[Math.max(0, Math.floor((pool.length - 1) / 4))]]
  const uniq = pick.filter((k, i) => pick.indexOf(k) === i)
  return (
    <div className="case-icon">
      <div className="case-aura" />
      <div className="case-row" style={{ gridTemplateColumns: `repeat(${uniq.length}, 50px)` }}>
        {uniq.map((k, i) => <div key={k} className={`ci ${uniq.length === 3 ? `ci${i}` : 'ci1'}`}><GiftArt kind={k} size={50} glow={false} /></div>)}
      </div>
    </div>
  )
}

function GiftsTab({ save, ctx, onBuy, onSell, onUpgrade }: { save: Save; ctx: Ctx; onBuy: (k: GiftKind) => void; onSell: (g: GiftT) => void; onUpgrade: (uid: string) => void }) {
  const [sub, setSub] = useState<'mine' | 'market'>('mine')
  const [kindF, setKindF] = useState<'gift' | 'nft'>('gift')
  const imported = GIFT_ORDER.some(k => !!GIFTS[k].thumb || /★/.test(GIFTS[k].name))
  const worth = save.gifts.reduce((a, g) => a + save.prices[g.kind], 0)
  return <section className="page-section">
    <h1>Подарки</h1>
    <div className="subtabs"><button className={sub === 'mine' ? 'on' : ''} onClick={() => setSub('mine')}>Мои</button><button className={sub === 'market' ? 'on' : ''} onClick={() => setSub('market')}>Маркет</button></div>
    {sub === 'mine' ? <>
      <div className="gift-sum"><span>{save.gifts.length} подарков</span><span>оценка {cfmt(worth)}</span></div>
      {!save.gifts.length && <div className="empty-history">Пока пусто. Загляни на маркет или открой кейс.</div>}
      {save.gifts.map(g => <div className="gift-row" key={g.uid}>
        <GiftArt kind={g.kind} size={48} />
        <div><b>{GIFTS[g.kind]?.name}</b><small>{GIFTS[g.kind].rarity}</small></div>
        <div className="gift-act"><strong>{cfmt(save.prices[g.kind])}</strong>
          <span><button onClick={() => onUpgrade(g.uid)}>Апгрейд</button><button onClick={() => onSell(g)}>Продать</button></span></div>
      </div>)}
    </> : <>
      <div className="gift-sum"><span>Цена в звёздах</span><span>продажа −{Math.round((1 - SELL_RATE) * 100)}%</span></div>
      <div className="subtabs slim"><button className={kindF === 'gift' ? 'on' : ''} onClick={() => setKindF('gift')}>Подарки</button>
        <button className={kindF === 'nft' ? 'on' : ''} onClick={() => setKindF('nft')}>NFT{GIFT_ORDER.some(k => GIFTS[k].nft) ? '' : ' (нет данных)'}</button></div>
      {kindF === 'nft' && !GIFT_ORDER.some(k => GIFTS[k].nft) && <div className="empty-history">NFT пока не загружены (нет доступа к интернету или к GitHub). Положи nft.json в public/gifts или запусти через бэкенд.</div>}
      {GIFT_ORDER.filter(k => !!GIFTS[k].nft === (kindF === 'nft')).map(k => {
        const p = save.prices[k], o = save.priceOpen.prices[k], d = ((p - o) / o) * 100
        return <div className="gift-row" key={k}>
          <GiftArt kind={k} size={48} />
          <div><b>{GIFTS[k]?.name}</b><small>{GIFTS[k].rarity}</small></div>
          <div className="gift-act"><strong>{cfmt(p)}</strong>{GIFTS[k].nft && <small>≈ {(p / COINS_PER_TON).toFixed(p / COINS_PER_TON < 10 ? 2 : 1).replace('.', ',')} TON</small>}<span className={d >= 0 ? 'up' : 'down'}>{d >= 0 ? '+' : '−'}{Math.abs(d).toFixed(1).replace('.', ',')}% за день</span>
            <span><button disabled={save.balance < p} onClick={() => onBuy(k)}>Купить</button></span></div>
        </div>
      })}
      {FLAGS.demo && <p className="fine-print demo">Демо-данные: иконки, названия и цены NFT сгенерированы для тестов и колеблются случайно. Настоящие появятся после импорта каталога из бота.</p>}
      {GIFT_ORDER.some(k => GIFTS[k].nft) && <p className="fine-print">Цены NFT: флоры Fragment по данным «Telegram gifts floor prices» (Baltic Assets, balticassets.eu) и «Telegram Gifts and Stars Dataset» (Gift Club), CC BY 4.0, обновляются раз в сутки.</p>}
      <p className="fine-print">{imported
        ? `Каталог импортирован из Telegram: ${GIFT_ORDER.length} подарков, цена в звёздах равна цене в Telegram (1★ = ${STARS_TO_COINS} звезда игры). Внутриигровые подарки на настоящие не обмениваются.`
        : 'Сейчас встроенный набор. Чтобы подтянуть настоящие подарки Telegram, запусти скрипт import-gifts (см. README).'}</p>
      <p className="fine-print">Цены внутри игры колеблются около базовых значений. {ctx.save.gifts.length ? '' : 'Купи подарок и попробуй апгрейд.'}</p>
    </>}
  </section>
}

function TransactionList({ items }: { items: Tx[] }) {
  if (!items.length) return <div className="empty-history">Пока нет операций</div>
  return <div className="tx-list">{items.map(tx => <div className="tx-row" key={tx.id}>
    <span className={tx.amount >= 0 ? 'tx-icon plus' : 'tx-icon'}>{tx.amount >= 0 ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}</span>
    <div><b>{tx.title}</b><small>{tx.date}</small></div>
    <strong className={tx.amount > 0 ? 'positive' : ''}>{tx.amount === 0 ? 'подарок' : `${tx.amount > 0 ? '+' : ''}${cfmt(tx.amount)}`}</strong>
  </div>)}</div>
}

function Confetti({ count }: { count: number }) {
  const pieces = useMemo(() => count <= 0 ? [] : Array.from({ length: 26 }, () => ({
    x: 50 + (Math.random() - 0.5) * 70, c: `hsl(${Math.floor(Math.random() * 360)},80%,60%)`, s: Math.random() * 6 + 3, d: Math.random() * 0.4,
  })), [count])
  return <div className="confetti-layer">{pieces.map((p, i) => <div key={i} className="confetti-piece" style={{ left: `${p.x}%`, background: p.c, width: p.s, height: p.s, animationDelay: `${p.d}s` }} />)}</div>
}
